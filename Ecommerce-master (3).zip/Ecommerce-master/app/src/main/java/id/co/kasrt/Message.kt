package id.co.kasrt

data class Message(val text: String, val isSentByUser: Boolean)