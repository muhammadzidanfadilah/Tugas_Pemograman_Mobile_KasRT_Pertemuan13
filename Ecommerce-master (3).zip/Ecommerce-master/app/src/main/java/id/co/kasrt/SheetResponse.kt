package id.co.kasrt

data class SheetResponse(
    val data: List<Map<String, String>> // Sesuaikan dengan format respons dari API Spreadsheets
)
